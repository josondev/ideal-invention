'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def set_all_even_elements_to_zero(l):
    
    for i in range(1, len(l) + 1, 2):
        l[i] = 0         

#print(set_all_even_elements_to_zero([1, 2, 3, 4, 5]))    


def is_sorted(l):
    flag=1
    for i in range(len(l)):
        for j in range(i,len(l)):
            if(l[i]>l[j]):
                flag=0
                break
    return(bool(flag))      
#print(is_sorted([5,4,3,2,1]))    

def sums_of_first_two_and_last_two_digits(n):
    n=str(n)
    sum1,sum2=0,0
    for i in range(len(n[0:2])):
        sum1+=int(n[0:2][i])
    for i in range(len(n[2:])):
        sum2+=int(n[2:][i])
    return((sum1,sum2))    

#print(sums_of_first_two_and_last_two_digits(1234))    